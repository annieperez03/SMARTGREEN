#include <Data_Mules_Management.h>
#include <RadioLib.h>
#include <Wire.h>
#include <SPI.h>
#include <Adafruit_BME680.h>
#include <OneWire.h>
#include <DallasTemperature.h>  
#include <BH1750.h>
#include <U8g2lib.h>

// Cambiamos SSD1306 por SH1106
U8G2_SH1106_128X64_NONAME_F_HW_I2C u8g2(U8G2_R2, U8X8_PIN_NONE);

#define DS18B20_PIN A0
OneWire oneWire(DS18B20_PIN);
DallasTemperature ds18b20(&oneWire);

BH1750 lightMeter;
Adafruit_BME680 bme;

#define FC28_PIN A1 
int valor_seco = 1023; //calibrar sensor FC28
int valor_en_agua = 800;

uint8_t payload[25]; //Datos recopilados 

uint8_t ID_mi_estacion = 3;
float humedad_FC28;
float lux_bh1750;
float tempDS18B20;
float tempBME, humBME, presBME;
uint32_t gasBME;

bool flag_otaa = 0;

bool bomba_agua = 0; //0 = apagada, 1 = encendida
const float UMBRAL_SECO  = 30.0; // Enciende bomba si baja de 30%
const float UMBRAL_OK = 70.0; // Apaga bomba si supera 70%
const float UMBRAL_LUX_MAXIMO  = 35000.0; // Umbral de sol directo alto

// Variables para TB6612
const int STBY = 13;

// Pines Canal A (Bomba 1)
const int PWMA = 5;
const int AIN2 = 9;
const int AIN1 = 6;

// Pines Canal B (Bomba 2)
const int PWMB = 10;
const int BIN2 = 12;
const int BIN1 = 11;

SX1276 radio = new Module(SS, RFM_DIO0, RFM_RST, RFM_DIO1);
LoRaWANNode node(&radio, &US915, 2);

uint64_t joinEUI = 0x3333333333333333;
uint64_t devEUI  = 0x70B3D57ED00788B9;
uint8_t newKey[] = {0x10, 0x93, 0xB3, 0x6B, 0x2B, 0x38, 0x63, 0xD4, 0x9E, 0x4C, 0xA7, 0x46, 0x4B, 0xB6, 0x3B, 0xBD};
uint8_t appKey[] = {0x10, 0x93, 0xB3, 0x6B, 0x2B, 0x38, 0x63, 0xD4, 0x9E, 0x4C, 0xA7, 0x46, 0x4B, 0xB6, 0x3B, 0xBD};

EstacionBastWAN estacion(DS18B20_PIN);// Instanciamos librería pasándole el pin del DS18B20

void escribirBits(uint8_t* buffer, int& bitOffset, uint32_t valor, int numBits) {
  for (int i = numBits - 1; i >= 0; i--) {
    int byteIndex = bitOffset / 8;
    int bitIndex = 7 - (bitOffset % 8);
    bool bitValor = (valor >> i) & 1;
    
    if (bitValor) buffer[byteIndex] |= (1 << bitIndex);
    else          buffer[byteIndex] &= ~(1 << bitIndex);
    bitOffset++;
  }
}

float mapFloat(float x, float in_min, float in_max, float out_min, float out_max) {
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

/*Envía tu arreglo de 25 bytes y verifica si el Gateway respondió con un ACK.*/
void enviar_mensaje(uint8_t* miPayload, uint8_t tamano) {
  Serial.print("Transmitiendo ");
  Serial.print(tamano);
  Serial.println(" bytes...");

  int state = node.sendReceive(miPayload, tamano, 10, false);

  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Transmisión enviada con éxito!");
  } else {
    Serial.print("Error al transmitir. Código: ");
    Serial.println(state);
  }
}

void actualizar_pantalla() {
  u8g2.clearBuffer();          
  u8g2.setFont(u8g2_font_6x10_tf);  

  // Línea 1: Device ID e Iluminación (Lux)
  u8g2.setCursor(0, 12);
  u8g2.print("ID:"); u8g2.print(ID_mi_estacion);
  u8g2.print(" O:"); u8g2.print(flag_otaa); //0 NO OTAA, 1 OTAA
  u8g2.print(" B:"); u8g2.print(bomba_agua); //0 apagada, 1 encendida 
  u8g2.print(" LX:"); u8g2.print(lux_bh1750); 

  // Línea 2: Humedad del suelo (FC28) y Temperatura DS18B20
  u8g2.setCursor(0, 28);
  u8g2.print("H.S:"); u8g2.print(humedad_FC28);
  u8g2.print(" TDS:"); u8g2.print(tempDS18B20);

  // Línea 3: Clima del BME680 (Temperatura y Humedad ambiental)
  u8g2.setCursor(0, 44);
  u8g2.print("TBME:"); u8g2.print(tempBME);
  u8g2.print(" HBME:"); u8g2.print(humBME);

  // Línea 4: Presión barométrica y Gas del BME680 
  u8g2.setCursor(0, 60);
  u8g2.print("P:"); u8g2.print(presBME);   
  u8g2.print(" G:"); u8g2.print(gasBME);       

  u8g2.sendBuffer(); 
}


void setup() {
  Serial.begin(115200);

  // TB6612
  // Configurar pines del Canal A como salida
  pinMode(PWMA, OUTPUT);
  pinMode(AIN1, OUTPUT);
  pinMode(AIN2, OUTPUT);

  // Configurar pines del Canal B como salida
  pinMode(PWMB, OUTPUT);
  pinMode(BIN1, OUTPUT);
  pinMode(BIN2, OUTPUT);

  pinMode(13, OUTPUT); //STANDBY
  digitalWrite(13, HIGH); 

  analogWrite(PWMA, 0);
  digitalWrite(AIN1, LOW);
  digitalWrite(AIN2, LOW);
  digitalWrite(BIN1, LOW);
  digitalWrite(BIN2, LOW);

  //Humedad de suelo
  pinMode(FC28_PIN, INPUT);
  
  //Sensor pantalla
  ds18b20.begin();

  //pantalla
  u8g2.begin();

  //Sensor de Luz
  lightMeter.begin();
  Serial.println(F("Sensor BH1750 iniciado..."));
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
     Serial.println(F("-> BH1750 inicializado correctamente."));
  } else {
    Serial.println(F("-> Error al inicializar BH1750."));
  }
  
  //Sensor BME
  if (!bme.begin(0x76)) { 
    Serial.println("Fallo al encontrar el BME680");
  } else {
    bme.setTemperatureOversampling(BME680_OS_8X);
    bme.setHumidityOversampling(BME680_OS_2X);
    bme.setPressureOversampling(BME680_OS_4X);
    bme.setIIRFilterSize(BME680_FILTER_SIZE_3);
    bme.setGasHeater(320, 150); // 320°C por 150 ms
  }


  
  // Inicializar modulo de  radio 
  Serial.print("Inicializando Radio ... ");
  int state = radio.begin();
  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Éxito!");
  } else {
    Serial.print("Falló el hardware. Código de error: ");
    Serial.println(state);
    while (true);
  }

  // Inicializar el nodo LoRaWAN con las llaves
  Serial.print("Configurando nodo LoRaWAN... ");
  state = node.beginOTAA(joinEUI, devEUI, newKey, appKey);
  if (state == RADIOLIB_ERR_NONE) {
    Serial.println("¡Listo!");
  } else {
    Serial.print("Error al configurar OTAA: ");
    Serial.println(state);
    while (true);
  }

  // Intentar unirse a TTN (Join)
  Serial.println("Solicitando Join por OTAA a la red...");
  state = node.activateOTAA();
  
  if (state == RADIOLIB_LORAWAN_NEW_SESSION) {
    Serial.println("----------------------------------------------");
    Serial.println("¡Unión exitosa! Sesión establecida en TTN.");
    flag_otaa = 1;
    Serial.println("----------------------------------------------");
  } else {
    Serial.println("----------------------------------------------");
    Serial.print("No se pudo unir. Código de error: ");
    Serial.println(state);
    Serial.println("----------------------------------------------");
    flag_otaa = 0;
  }

  actualizar_pantalla(); //Imprimir datos en pantalla

}

void loop() {
  Serial.println("--------LEER SENSORES Y MOSTRAR LECTURA--------");  
  int lecturaRaw = analogRead(FC28_PIN);
  float humedadSueloFloat = mapFloat(lecturaRaw, valor_seco, valor_en_agua, 0.0, 100.0);
  if (humedadSueloFloat < 0.0) humedadSueloFloat = 0.0;
  if (humedadSueloFloat > 100.0) humedadSueloFloat = 100.0;
  
  humedad_FC28 = humedadSueloFloat;
  
  ds18b20.requestTemperatures();
  tempDS18B20 = ds18b20.getTempCByIndex(0);

  if (bme.performReading()) {
    tempBME = bme.temperature;
    humBME = bme.humidity;
    presBME = bme.pressure / 100.0; 
    gasBME = bme.gas_resistance;
  }

  float luxesFloat = lightMeter.readLightLevel();
  if (luxesFloat < 0.0) luxesFloat = 0.0;
  lux_bh1750 = luxesFloat;


  if (humedad_FC28 < UMBRAL_SECO) {
    Serial.println("ALERTA: Suelo seco. Entrando a ciclo de riego dedicado...");
    bomba_agua = 1;
  }
  else{
    bomba_agua = 0;
  }

  Serial.print("Temp BME680: "); 
  Serial.println(tempBME);
  Serial.print("Temp DS18B2: "); 
  Serial.println(tempDS18B20);
  actualizar_pantalla(); //Imprimir datos en pantalla

  //--------------------------------------------------------------------------------------------
  Serial.println("--------Armar Payload--------"); 

  memset(payload, 0, 25); 
  int bitOffset = 0; 

  escribirBits(payload, bitOffset, ID_mi_estacion, 8);
  
  uint32_t ds18TempCod = (tempDS18B20 == -127.0) ? 2332 : round((tempDS18B20 + 55.0) / 0.0625); 
  uint32_t bmeTempCod = (tempBME == 0.0) ? 0 : round((tempBME + 40.0) * 100.0);
  uint32_t bmeHumCod  = (humBME == 0.0)  ? 0 : round(humBME * 10.0);
  uint32_t bmeGasCod  = (gasBME == 0.0)  ? 0 : constrain(gasBME, 0, 500000);
  uint32_t bmePresCod = (presBME == 0.0) ? 0 : round((presBME - 500.0)*(8191.0/600.0));
  uint32_t FC28HumCod = humedad_FC28*(100.0 / 8191.0);
  uint32_t BH1750LuxCod = lux_bh1750;

  bool bombaCod = bomba_agua; //ajustar para ver si encender o no si encendida entonces = 1

  
  escribirBits(payload, bitOffset, ds18TempCod, 12);
  escribirBits(payload, bitOffset, bmeTempCod, 14);
  escribirBits(payload, bitOffset, bmeHumCod, 10);
  escribirBits(payload, bitOffset, bmeGasCod, 16);
  escribirBits(payload, bitOffset, bmePresCod, 13);
  escribirBits(payload, bitOffset, FC28HumCod, 13);
  escribirBits(payload, bitOffset, BH1750LuxCod, 16);
  escribirBits(payload, bitOffset, bombaCod, 1);
  Serial.print("Temp BME680 COD: "); 
  Serial.println(bmeTempCod);
  

  //--------------------------------------------------------------------------------------------

  Serial.println("--------Enviar Payload por LoRa--------"); 
  if (node.isActivated()) {
    flag_otaa = 1;
    node.setDatarate(3);
    enviar_mensaje(payload, sizeof(payload)); 

  } else {
    flag_otaa = 0;
    Serial.println("Dispositivo desconectado de TTN OTAA. Intentando unirse de nuevo...");
    node.activateOTAA();
  }


  if (humedad_FC28 < UMBRAL_SECO) {
    Serial.println("ALERTA: Suelo seco. Entrando a ciclo de riego dedicado...");
    
    // BUCLE ENCICLADO: Mientras la humedad NO alcance el nivel deseado
    while (humedad_FC28 < UMBRAL_OK) {
      bomba_agua = 1;
      digitalWrite(STBY, HIGH);
      digitalWrite(AIN1, HIGH);
      digitalWrite(AIN2, LOW);
      digitalWrite(BIN1, HIGH);
      digitalWrite(BIN2, LOW);

      // 1. EVALUAR NIVEL DE LUZ / SOL PARA AJUSTAR LA POTENCIA DE LA BOMBA
      if (lux_bh1750 > UMBRAL_LUX_MAXIMO) {
        analogWrite(PWMA, 150); // Riego suave/moderado (60% potencia) si hay sol directo fuerte
        Serial.println("  -> Aplicando dosis de agua (Modo Sol Fuerte - Potencia reducida)...");
      } else {
        analogWrite(PWMA, 255); // Riego normal (100% potencia)
        Serial.println("  -> Aplicando dosis de agua (Potencia máxima)...");
      }
      
      delay(3000); // Riega durante 3 segundos

      // 2. Apagar la bomba
      analogWrite(PWMA, 0);
      digitalWrite(AIN1, LOW);
      digitalWrite(AIN2, LOW);
      digitalWrite(BIN1, LOW);
      digitalWrite(BIN2, LOW);

      // Actualizar pantalla al iniciar la bomba (para que muestre BMB: 1 de inmediato)
      actualizar_pantalla();
      bomba_agua = 0;

      // Actualizar pantalla al apagar la bomba (muestra BMB: 0 durante la pausa)
      actualizar_pantalla();
      
      // 3. Dar tiempo para que el agua penetre la tierra hasta el FC28
      Serial.println("  -> Bomba en pausa. Esperando infiltración (10 seg)...");
      delay(10000); // 10 segundos de absorción

      // 4. Releer la humedad DEL SUELO Y LA LUZ para la siguiente iteración
      int lecturaRaw = analogRead(FC28_PIN);
      float humedadSueloFloat = mapFloat(lecturaRaw, valor_seco, valor_en_agua, 0.0, 100.0);
      if (humedadSueloFloat < 0.0) humedadSueloFloat = 0.0;
      if (humedadSueloFloat > 100.0) humedadSueloFloat = 100.0;
      
      humedad_FC28 = humedadSueloFloat; // Actualiza condición del while

      // Releer la luz por si las nubes o el sol cambiaron durante la pausa
      float luxesFloat = lightMeter.readLightLevel();
      if (luxesFloat < 0.0) luxesFloat = 0.0;
      lux_bh1750 = luxesFloat;
      
      Serial.print("  -> Nueva humedad registrada: ");
      Serial.print(humedad_FC28);
      Serial.println("%");
      actualizar_pantalla();
    }

    Serial.println("RIEGO COMPLETADO: Humedad ideal alcanzada... ");

  }
  else{
    analogWrite(PWMA, 0);
    digitalWrite(AIN1, LOW);
    digitalWrite(AIN2, LOW);
    digitalWrite(BIN1, LOW);
    digitalWrite(BIN2, LOW);

  }

  delay(60000); // Esperar un tiempo antes de volver a leer sensores
}